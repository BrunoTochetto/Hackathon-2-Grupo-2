﻿const assert = require('assert');
const { calculateProductionDecision, getTipoHorario, calculate15MinRollingStats } = require('../server');

console.log("=== INICIANDO TESTES DO MOTOR SMARTBUFFET STREAM ===");

// ----------------------------------------------------
// TESTE 1: MATRIZ DE DECISÃO DE PRODUÇÃO
// ----------------------------------------------------
console.log("\n[1] Testando Regras da Matriz de Decisão...");

// 1.1 Horário de Pico
assert.strictEqual(calculateProductionDecision('PICO', 0), 'AUMENTAR PRODUÇÃO', 'PICO com saldo 0 deve AUMENTAR');
assert.strictEqual(calculateProductionDecision('PICO', 12), 'AUMENTAR PRODUÇÃO', 'PICO com saldo positivo deve AUMENTAR');
assert.strictEqual(calculateProductionDecision('PICO', -6), 'ESTAGNAÇÃO (MANTER)', 'PICO com saldo < -5 deve MANTER');
assert.strictEqual(calculateProductionDecision('PICO', -3), 'ESTAGNAÇÃO (MANTER)', 'PICO com saldo entre -5 e 0 deve MANTER');
console.log("  ✔ Regras de Horário de Pico: PASSOU");

// 1.2 Horário Normal
assert.strictEqual(calculateProductionDecision('NORMAL', 6), 'AUMENTAR PRODUÇÃO', 'NORMAL com saldo > 5 deve AUMENTAR');
assert.strictEqual(calculateProductionDecision('NORMAL', 5), 'ESTAGNAÇÃO (MANTER)', 'NORMAL com saldo 5 deve MANTER');
assert.strictEqual(calculateProductionDecision('NORMAL', 0), 'ESTAGNAÇÃO (MANTER)', 'NORMAL com saldo 0 deve MANTER');
assert.strictEqual(calculateProductionDecision('NORMAL', -5), 'ESTAGNAÇÃO (MANTER)', 'NORMAL com saldo -5 deve MANTER');
assert.strictEqual(calculateProductionDecision('NORMAL', -6), 'BAIXA DE PRODUÇÃO', 'NORMAL com saldo < -5 deve BAIXAR');
console.log("  ✔ Regras de Horário Normal: PASSOU");

// 1.3 Horário de Baixa
assert.strictEqual(calculateProductionDecision('BAIXA', 10), 'BAIXA DE PRODUÇÃO', 'BAIXA com qualquer saldo deve BAIXAR');
assert.strictEqual(calculateProductionDecision('BAIXA', -2), 'BAIXA DE PRODUÇÃO', 'BAIXA deve BAIXAR');
console.log("  ✔ Regras de Horário de Baixa: PASSOU");

// ----------------------------------------------------
// TESTE 2: RECONHECIMENTO DE FAIXA DE HORÁRIO
// ----------------------------------------------------
console.log("\n[2] Testando Reconhecimento de Horário...");

const restauranteMock = {
  dias_semana: {
    quarta: {
      pico: [{ inicio: '12:00', fim: '14:00' }],
      baixa: [{ inicio: '14:00', fim: '15:00' }]
    }
  }
};

assert.strictEqual(getTipoHorario(restauranteMock, 'quarta', '11:59'), 'NORMAL');
assert.strictEqual(getTipoHorario(restauranteMock, 'quarta', '12:00'), 'PICO');
assert.strictEqual(getTipoHorario(restauranteMock, 'quarta', '13:30'), 'PICO');
assert.strictEqual(getTipoHorario(restauranteMock, 'quarta', '14:00'), 'PICO');
assert.strictEqual(getTipoHorario(restauranteMock, 'quarta', '14:30'), 'BAIXA');
assert.strictEqual(getTipoHorario(restauranteMock, 'quarta', '15:00'), 'BAIXA');
assert.strictEqual(getTipoHorario(restauranteMock, 'quarta', '15:01'), 'NORMAL');
console.log("  ✔ Faixas de Pico e Baixa: PASSOU");

// ----------------------------------------------------
// TESTE 3: JANELA MÓVEL DE 15 MINUTOS
// ----------------------------------------------------
console.log("\n[3] Testando Janela Móvel dos Últimos 15 Minutos...");

const agora = Date.now();
const vinteMinAtras = agora - (20 * 60 * 1000);
const dezMinAtras = agora - (10 * 60 * 1000);
const doisMinAtras = agora - (2 * 60 * 1000);

const restHistoricoMock = {
  historico_movimentos: [
    { tipo: 'ENTRADA', quantidade: 10, timestamp: vinteMinAtras }, // Deve ser IGNORADO (fora dos 15m)
    { tipo: 'ENTRADA', quantidade: 5,  timestamp: dezMinAtras },   // Válido (+5)
    { tipo: 'ENTRADA', quantidade: 1,  timestamp: doisMinAtras },  // Válido (+1)
    { tipo: 'SAIDA',   quantidade: 2,  timestamp: doisMinAtras }   // Válido (-2)
  ]
};

const stats = calculate15MinRollingStats(restHistoricoMock);
assert.strictEqual(stats.entradas_15min, 6, 'Total de entradas válidas deve ser 6');
assert.strictEqual(stats.saidas_15min, 2, 'Total de saídas válidas deve ser 2');
assert.strictEqual(stats.saldo_fluxo_15min, 4, 'Saldo deve ser 6 - 2 = 4');
console.log("  ✔ Cálculo da Janela Móvel de 15 Minutos: PASSOU");

console.log("\n====================================================");
console.log(" TODOS OS TESTES PASSARAM COM SUCESSO! (100% OK) ");
console.log("====================================================\n");
process.exit(0);
