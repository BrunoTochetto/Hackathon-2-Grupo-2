﻿// =========================================================
// SMARTBUFFET STREAM - LÓGICA DO CLIENTE (FRONT-END)
// =========================================================

const socket = io();

// Estado Local da Aplicação
const appState = {
  restauranteId: null,
  restauranteNome: null,
  papel: null, // "RECEPCAO" ou "COZINHA"
  diasSemana: {},
  diaSelecionado: 'segunda',
  ultimoEstadoProducao: null,
  somAtivado: true
};

// Sintetizador de Som com Web Audio API (Totalmente Offline e Independente de Arquivos)
let audioCtx = null;
function playStateChangeSound(estado) {
  if (!appState.somAtivado) return;
  try {
    if (!audioCtx) {
      audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }

    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.connect(gain);
    gain.connect(audioCtx.destination);

    if (estado.includes('AUMENTAR')) {
      // Tom agudo ascendente alegre (duplo bip)
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(523.25, audioCtx.currentTime); // C5
      osc.frequency.exponentialRampToValueAtTime(783.99, audioCtx.currentTime + 0.25); // G5
      gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4);
      osc.start(audioCtx.currentTime);
      osc.stop(audioCtx.currentTime + 0.4);
    } else if (estado.includes('BAIXA')) {
      // Tom grave descendente de atenção
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(440, audioCtx.currentTime); // A4
      osc.frequency.exponentialRampToValueAtTime(220, audioCtx.currentTime + 0.3); // A3
      gain.gain.setValueAtTime(0.2, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.45);
      osc.start(audioCtx.currentTime);
      osc.stop(audioCtx.currentTime + 0.45);
    } else {
      // Tom suave de estabilização
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, audioCtx.currentTime);
      gain.gain.setValueAtTime(0.15, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
      osc.start(audioCtx.currentTime);
      osc.stop(audioCtx.currentTime + 0.3);
    }
  } catch (err) {
    console.warn('AudioContext não pôde ser iniciado sem interação prévia:', err);
  }
}

// =========================================================
// ELEMENTOS DO DOM
// =========================================================

const screens = {
  login: document.getElementById('view-login'),
  recepcao: document.getElementById('view-recepcao'),
  cozinha: document.getElementById('view-cozinha')
};

// Login
const loginForm = document.getElementById('login-form');
const inputRestId = document.getElementById('input-rest-id');
const inputSenha = document.getElementById('input-senha');
const loginError = document.getElementById('login-error');

// Recepção
const recRestName = document.getElementById('rec-rest-name');
const recClock = document.getElementById('rec-clock');
const recTipoHorario = document.getElementById('rec-tipo-horario');
const recEntradas = document.getElementById('rec-entradas');
const recSaidas = document.getElementById('rec-saidas');
const recSaldo = document.getElementById('rec-saldo');
const recEstadoProd = document.getElementById('rec-estado-prod');
const recMovimentosTbody = document.getElementById('rec-movimentos-tbody');
const btnRecLogout = document.getElementById('btn-rec-logout');

// Cozinha
const cozRestName = document.getElementById('coz-rest-name');
const cozCommandBox = document.getElementById('coz-command-box');
const cozMainDisplay = document.querySelector('.cozinha-main-display');
const cozEstadoTexto = document.getElementById('coz-estado-texto');
const cozDiaSemana = document.getElementById('coz-dia-semana');
const cozTipoHorario = document.getElementById('coz-tipo-horario');
const cozSaldoFluxo = document.getElementById('coz-saldo-fluxo');
const cozHoraAtual = document.getElementById('coz-hora-atual');
const btnCozLogout = document.getElementById('btn-coz-logout');
const btnToggleSound = document.getElementById('btn-toggle-sound');

// Configuração de Horários
const dayTabs = document.querySelectorAll('.day-tab');
const currentDayLabel = document.getElementById('current-day-label');
const inputPicoInicio = document.getElementById('input-pico-inicio');
const inputPicoFim = document.getElementById('input-pico-fim');
const inputBaixaInicio = document.getElementById('input-baixa-inicio');
const inputBaixaFim = document.getElementById('input-baixa-fim');
const btnSalvarHorarios = document.getElementById('btn-salvar-horarios');
const saveHorariosFeedback = document.getElementById('save-horarios-feedback');

// Nomes amigáveis para os dias da semana
const DIAS_NOMES = {
  segunda: 'Segunda-feira',
  terca: 'Terça-feira',
  quarta: 'Quarta-feira',
  quinta: 'Quinta-feira',
  sexta: 'Sexta-feira',
  sabado: 'Sábado',
  domingo: 'Domingo'
};

// =========================================================
// NAVEGAÇÃO DE TELAS
// =========================================================

function showScreen(screenKey) {
  Object.keys(screens).forEach((key) => {
    screens[key].classList.remove('active');
  });
  screens[screenKey].classList.add('active');
}

// Relógio Local no Painel da Recepção
setInterval(() => {
  if (recClock && appState.papel === 'RECEPCAO') {
    const agora = new Date();
    recClock.textContent = agora.toLocaleTimeString('pt-BR');
  }
}, 1000);

// =========================================================
// 1. FLUXO DE AUTENTICAÇÃO E SELEÇÃO DE PAPEL
// =========================================================

loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  loginError.classList.add('hidden');

  const restaurante_id = inputRestId.value.trim();
  const senha = inputSenha.value.trim();
  const papelRadio = document.querySelector('input[name="role"]:checked');
  const papel = papelRadio ? papelRadio.value : 'RECEPCAO';

  socket.emit('entrar_restaurante', { restaurante_id, senha, papel }, (response) => {
    if (!response || !response.sucesso) {
      loginError.textContent = response ? response.mensagem : 'Erro ao conectar ao servidor.';
      loginError.classList.remove('hidden');
      return;
    }

    appState.restauranteId = restaurante_id;
    appState.restauranteNome = response.restaurante_nome;
    appState.papel = papel;
    appState.diasSemana = response.dias_semana || {};

    if (papel === 'RECEPCAO') {
      recRestName.textContent = appState.restauranteNome;
      loadDayScheduleToInputs(appState.diaSelecionado);
      showScreen('recepcao');
    } else {
      cozRestName.textContent = appState.restauranteNome;
      showScreen('cozinha');
    }

    if (response.estado_inicial) {
      updateUIWithStream(response.estado_inicial);
    }
  });
});

function handleLogout() {
  appState.restauranteId = null;
  appState.papel = null;
  appState.ultimoEstadoProducao = null;
  showScreen('login');
}

btnRecLogout.addEventListener('click', handleLogout);
btnCozLogout.addEventListener('click', handleLogout);

// Alternar Alerta Sonoro na Cozinha
btnToggleSound.addEventListener('click', () => {
  appState.somAtivado = !appState.somAtivado;
  if (appState.somAtivado) {
    btnToggleSound.textContent = '🔔 Alerta Sonoro: Ativado';
    btnToggleSound.classList.remove('muted');
  } else {
    btnToggleSound.textContent = '🔕 Alerta Sonoro: Mudo';
    btnToggleSound.classList.add('muted');
  }
});

// =========================================================
// 2. PAINEL DA RECEPÇÃO: REGISTRO DE FLUXO (+1, +5, -1, -5)
// =========================================================

function registerFlow(tipo, quantidade) {
  if (!appState.restauranteId) return;
  socket.emit('registrar_fluxo', {
    restaurante_id: appState.restauranteId,
    tipo,
    quantidade
  });
}

document.getElementById('btn-in-1').addEventListener('click', () => registerFlow('ENTRADA', 1));
document.getElementById('btn-in-5').addEventListener('click', () => registerFlow('ENTRADA', 5));
document.getElementById('btn-out-1').addEventListener('click', () => registerFlow('SAIDA', 1));
document.getElementById('btn-out-5').addEventListener('click', () => registerFlow('SAIDA', 5));

// =========================================================
// 3. ATUALIZAÇÃO REATIVA DO STREAM WEBSOCKET
// =========================================================

socket.on('stream_estado', (payload) => {
  if (!payload || payload.restaurante_id !== appState.restauranteId) return;
  updateUIWithStream(payload);
});

socket.on('horarios_atualizados', ({ dias_semana }) => {
  appState.diasSemana = dias_semana;
  if (appState.papel === 'RECEPCAO') {
    loadDayScheduleToInputs(appState.diaSelecionado);
  }
});

function updateUIWithStream(data) {
  const {
    estado_producao,
    saldo_fluxo_15min,
    entradas_15min,
    saidas_15min,
    tipo_horario_atual,
    dia_semana,
    hora_atual,
    ultimos_movimentos
  } = data;

  // Se o estado mudou na Cozinha, emitir aviso sonoro
  if (appState.ultimoEstadoProducao && appState.ultimoEstadoProducao !== estado_producao) {
    playStateChangeSound(estado_producao);
  }
  appState.ultimoEstadoProducao = estado_producao;

  // ----------------------------------------------------
  // Atualização da Visão da Cozinha
  // ----------------------------------------------------
  if (appState.papel === 'COZINHA') {
    cozEstadoTexto.textContent = estado_producao;

    // Remove todas as classes de background anteriores
    cozMainDisplay.classList.remove('bg-aumentar', 'bg-manter', 'bg-baixa');

    if (estado_producao.includes('AUMENTAR')) {
      cozMainDisplay.classList.add('bg-aumentar');
    } else if (estado_producao.includes('BAIXA')) {
      cozMainDisplay.classList.add('bg-baixa');
    } else {
      cozMainDisplay.classList.add('bg-manter');
    }

    // Rodapé discreto
    const diaFormatado = DIAS_NOMES[dia_semana] || dia_semana;
    cozDiaSemana.textContent = diaFormatado;
    
    let tipoHorarioFormatado = 'Horário Normal';
    if (tipo_horario_atual === 'PICO') tipoHorarioFormatado = 'Horário de Pico';
    if (tipo_horario_atual === 'BAIXA') tipoHorarioFormatado = 'Horário de Baixa';
    cozTipoHorario.textContent = tipoHorarioFormatado;

    const saldoFormatado = (saldo_fluxo_15min > 0 ? `+${saldo_fluxo_15min}` : `${saldo_fluxo_15min}`);
    cozSaldoFluxo.textContent = `${saldoFormatado} (Entradas: ${entradas_15min} | Saídas: ${saidas_15min})`;
    cozHoraAtual.textContent = hora_atual;
  }

  // ----------------------------------------------------
  // Atualização da Visão da Recepção
  // ----------------------------------------------------
  if (appState.papel === 'RECEPCAO') {
    // Tipo de Horário
    recTipoHorario.textContent = tipo_horario_atual;
    recTipoHorario.className = 'status-pill';
    if (tipo_horario_atual === 'PICO') recTipoHorario.classList.add('pico');
    if (tipo_horario_atual === 'BAIXA') recTipoHorario.classList.add('baixa');

    // Métricas dos últimos 15 min
    recEntradas.textContent = entradas_15min;
    recSaidas.textContent = saidas_15min;

    const prefixo = saldo_fluxo_15min > 0 ? '+' : '';
    recSaldo.textContent = `${prefixo}${saldo_fluxo_15min}`;
    if (saldo_fluxo_15min > 0) {
      recSaldo.className = 'metric-value text-success';
    } else if (saldo_fluxo_15min < 0) {
      recSaldo.className = 'metric-value text-danger';
    } else {
      recSaldo.className = 'metric-value';
    }

    // Badge do estado de produção
    recEstadoProd.textContent = estado_producao;
    recEstadoProd.className = 'summary-badge';
    if (estado_producao.includes('AUMENTAR')) {
      recEstadoProd.classList.add('state-aumentar');
    } else if (estado_producao.includes('BAIXA')) {
      recEstadoProd.classList.add('state-baixa');
    } else {
      recEstadoProd.classList.add('state-manter');
    }

    // Tabela de Últimos Movimentos
    renderMovementHistoryTable(ultimos_movimentos || []);
  }
}

function renderMovementHistoryTable(movimentos) {
  if (!recMovimentosTbody) return;

  if (movimentos.length === 0) {
    recMovimentosTbody.innerHTML = '<tr><td colspan="3" class="text-center">Nenhum movimento recente</td></tr>';
    return;
  }

  recMovimentosTbody.innerHTML = movimentos.map((mov) => {
    const isEntrada = mov.tipo === 'ENTRADA';
    const tagClass = isEntrada ? 'text-success' : 'text-danger';
    const sinal = isEntrada ? '+' : '-';
    return `
      <tr>
        <td>${mov.horaFormatada || '--:--'}</td>
        <td class="${tagClass}"><strong>${mov.tipo}</strong></td>
        <td><strong>${sinal}${mov.quantidade}</strong></td>
      </tr>
    `;
  }).join('');
}

// =========================================================
// 4. EDITOR DE HORÁRIOS POR DIA DA SEMANA
// =========================================================

dayTabs.forEach((tab) => {
  tab.addEventListener('click', () => {
    dayTabs.forEach((t) => t.classList.remove('active'));
    tab.classList.add('active');
    appState.diaSelecionado = tab.dataset.day;
    loadDayScheduleToInputs(appState.diaSelecionado);
  });
});

function loadDayScheduleToInputs(dia) {
  currentDayLabel.textContent = DIAS_NOMES[dia] || dia;
  saveHorariosFeedback.textContent = '';

  const configDia = appState.diasSemana[dia] || { pico: [], baixa: [] };

  const pico = (configDia.pico && configDia.pico[0]) || { inicio: '12:00', fim: '14:00' };
  const baixa = (configDia.baixa && configDia.baixa[0]) || { inicio: '14:00', fim: '15:00' };

  inputPicoInicio.value = pico.inicio || '12:00';
  inputPicoFim.value = pico.fim || '14:00';
  inputBaixaInicio.value = baixa.inicio || '14:00';
  inputBaixaFim.value = baixa.fim || '15:00';
}

btnSalvarHorarios.addEventListener('click', () => {
  const dia = appState.diaSelecionado;

  appState.diasSemana[dia] = {
    pico: [{ inicio: inputPicoInicio.value, fim: inputPicoFim.value }],
    baixa: [{ inicio: inputBaixaInicio.value, fim: inputBaixaFim.value }]
  };

  socket.emit('atualizar_horarios', {
    restaurante_id: appState.restauranteId,
    dias_semana: appState.diasSemana
  }, (resp) => {
    if (resp && resp.sucesso) {
      saveHorariosFeedback.textContent = '✔ Horários salvos com sucesso!';
      setTimeout(() => { saveHorariosFeedback.textContent = ''; }, 3000);
    }
  });
});

// =========================================================
// 5. FERRAMENTAS DE SIMULAÇÃO & DEMONSTRAÇÃO
// =========================================================

const simButtons = document.querySelectorAll('.btn-sim');
simButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    simButtons.forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');

    const horaSimulada = btn.dataset.time || null;
    socket.emit('definir_hora_simulada', {
      restaurante_id: appState.restauranteId,
      hora_simulada: horaSimulada
    });
  });
});

document.getElementById('btn-limpar-fluxo').addEventListener('click', () => {
  if (confirm('Deseja zerar todos os lançamentos em memória deste restaurante?')) {
    socket.emit('limpar_historico', { restaurante_id: appState.restauranteId });
  }
});
